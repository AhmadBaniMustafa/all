import { QRCodeSVG } from 'qrcode.react';
import { useState, useEffect } from 'react';

const QRCode = () => {
  const [url, setUrl] = useState('');

  useEffect(() => {
    setUrl(window.location.href);
  }, []);

  return (
    <div className="fixed bottom-4 right-4 bg-white p-4 rounded-lg shadow-lg">
      <QRCodeSVG value={url} size={128} />
      <p className="text-sm text-center mt-2">Scan to open on phone</p>
    </div>
  );
};

export default QRCode;