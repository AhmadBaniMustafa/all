import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface CoffeeCardProps {
  title: string;
  image: string;
  price: string;
}

const CoffeeCard = ({ title, image, price }: CoffeeCardProps) => {
  return (
    <Card className="card-hover">
      <CardContent className="p-0">
        <img
          src={image}
          alt={title}
          className="w-full h-48 object-cover rounded-t-lg"
        />
        <div className="p-4">
          <h3 className="text-lg font-semibold">{title}</h3>
          <p className="text-muted-foreground mt-1">{price}</p>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button className="w-full">Order Now</Button>
      </CardFooter>
    </Card>
  );
};

export default CoffeeCard;