import Navigation from "@/components/Navigation";
import CoffeeCard from "@/components/CoffeeCard";
import QRCode from "@/components/QRCode";

const coffees = [
  {
    title: "Dark Roast Blend",
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd",
    price: "$4.99"
  },
  {
    title: "Medium Roast",
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085",
    price: "$5.99"
  },
  {
    title: "Espresso Blend",
    image: "https://images.unsplash.com/photo-1447933601403-0c6688de566e",
    price: "$3.99"
  },
  {
    title: "Colombian Supreme",
    image: "https://images.unsplash.com/photo-1509042239860-f550ce710b93",
    price: "$6.99"
  },
  {
    title: "Ethiopian Yirgacheffe",
    image: "https://images.unsplash.com/photo-1511920170033-f8396924c348",
    price: "$5.49"
  },
  {
    title: "French Vanilla",
    image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735",
    price: "$4.79"
  }
];

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      
      {/* Hero Section */}
      <div className="relative h-[80vh] flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1447933601403-0c6688de566e"
            alt="Coffee Hero"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 hero-gradient" />
        </div>
        <div className="container mx-auto px-4 relative text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Crafted Code, <br />Perfect Coffee
          </h1>
          <p className="text-xl md:text-2xl max-w-xl">
            Where developers meet exceptional coffee experiences
          </p>
        </div>
      </div>

      {/* Featured Coffee Section */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Featured Brews</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {coffees.map((coffee) => (
            <CoffeeCard
              key={coffee.title}
              title={coffee.title}
              image={coffee.image}
              price={coffee.price}
            />
          ))}
        </div>
      </section>

      <QRCode />
    </div>
  );
};

export default Index;